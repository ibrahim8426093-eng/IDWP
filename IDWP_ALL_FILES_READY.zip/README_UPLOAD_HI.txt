IDWP - Upload package

IMPORTANT: This ZIP is a project bundle. Extract it first. The files are arranged from the project root.

GitHub: Upload/replace the root files and folders while preserving the folder structure. Commit changes.
Vercel: If connected to this GitHub repository, it should redeploy after commit. Ensure Vercel Root Directory is the repository root.

Required Vercel Environment Variables must already be configured. This ZIP does not contain secret keys. Keep Firebase/Resend/payment secrets in Vercel Environment Variables, never in public files.

The /api folder contains one catch-all function; endpoint handlers are under /handlers to reduce the Vercel Hobby function count.

After deploy, test registration email confirmation, login, referrals, profile changes, payments and withdrawals before using the site.
