const { initFirebase, methodGuard } = require("../firebase-helper");
const PACKAGES = {"Lead Generation":460,"Commission Skill":400,"Data Entry":488,"Video Editing":500,"Freelancing":350,"Content Creation":300};
const normalizeMobile = v => String(v || "").replace(/\D/g, "");
module.exports = async function handler(req, res) {
  if (methodGuard(req, res)) return;
  try {
    const admin = initFirebase();
    const db = admin.firestore();
    const authHeader = String(req.headers.authorization || "");
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return res.status(401).json({error:"Please sign in to begin registration."});
    const decoded = await admin.auth().verifyIdToken(token);
    const authUser = await admin.auth().getUser(decoded.uid);
    const {name,mobile,whatsappNumber,email,referralId,package:packageName} = req.body || {};
    const normalizedEmail = String(email || "").trim().toLowerCase();
    const m = normalizeMobile(mobile), wa = normalizeMobile(whatsappNumber);
    const ref = String(referralId || "").trim().toUpperCase();
    if (!authUser.email || authUser.email.toLowerCase() !== normalizedEmail) return res.status(400).json({error:"Registration email does not match the signed-in account."});
    if (!String(name || "").trim()) return res.status(400).json({error:"Full name is required."});
    if (!/^[6-9]\d{9}$/.test(m) || !/^[6-9]\d{9}$/.test(wa)) return res.status(400).json({error:"Enter valid 10-digit Indian mobile and WhatsApp numbers."});
    if (!ref) return res.status(400).json({error:"Referral ID is required."});
    if (!PACKAGES[packageName]) return res.status(400).json({error:"Please select a valid package."});
    const existing = await db.collection("users").where("mobileNormalized","==",m).limit(1).get();
    if (!existing.empty) return res.status(409).json({error:"This mobile number is already registered with IDWP."});
    const referral = await db.collection("users").where("userID","==",ref).limit(1).get();
    if (referral.empty) return res.status(400).json({error:"Referral ID was not found. Please check it and try again."});
    const pendingRef = db.collection("pendingRegistrations").doc(decoded.uid);
    const prior = await pendingRef.get();
    if (prior.exists && prior.data().email !== normalizedEmail) return res.status(409).json({error:"A different registration is already pending for this account."});
    await pendingRef.set({uid:decoded.uid,email:normalizedEmail,name:String(name).trim(),mobile:m,mobileNormalized:m,whatsapp:wa,referral:ref,package:packageName,packagePrice:PACKAGES[packageName],createdAt:admin.firestore.FieldValue.serverTimestamp(),updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});
    return res.status(200).json({success:true,message:"Pending registration saved. Verify your email to finish."});
  } catch (e) {
    console.error("begin-registration error:", e.message);
    return res.status(500).json({error:"Could not start registration. Please try again."});
  }
};
