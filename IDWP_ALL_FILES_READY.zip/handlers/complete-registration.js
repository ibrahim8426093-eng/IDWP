const { initFirebase, methodGuard } = require("../firebase-helper");
const PACKAGES = {"Lead Generation":460,"Commission Skill":400,"Data Entry":488,"Video Editing":500,"Freelancing":350,"Content Creation":300};
function generateUserID(){ return "IDWP" + Math.floor(100000 + Math.random()*900000); }
module.exports = async function handler(req, res) {
  if (methodGuard(req, res)) return;
  try {
    const admin = initFirebase();
    const db = admin.firestore();
    const authHeader = String(req.headers.authorization || "");
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return res.status(401).json({error:"Please log in after verifying your email, then try again."});
    const decoded = await admin.auth().verifyIdToken(token);
    const authUser = await admin.auth().getUser(decoded.uid);
    if (!authUser.emailVerified) return res.status(403).json({error:"Email is not verified yet. Open the verification link from your email first."});
    const userRef = db.collection("users").doc(decoded.uid);
    const existingUser = await userRef.get();
    if (existingUser.exists) {
      const d = existingUser.data();
      return res.status(200).json({success:true,userID:d.userID,registration:{name:d.name,whatsapp:d.whatsapp,package:d.package},alreadyCompleted:true});
    }
    const pendingRef = db.collection("pendingRegistrations").doc(decoded.uid);
    const pendingSnap = await pendingRef.get();
    if (!pendingSnap.exists) return res.status(404).json({error:"Pending registration details were not found. Please start registration again using the same email."});
    const p = pendingSnap.data();
    if (!authUser.email || authUser.email.toLowerCase() !== String(p.email||"").toLowerCase()) return res.status(403).json({error:"Verified email does not match pending registration."});
    if (!PACKAGES[p.package]) return res.status(400).json({error:"Invalid package in pending registration."});
    const duplicateMobile = await db.collection("users").where("mobileNormalized","==",p.mobileNormalized).limit(1).get();
    if (!duplicateMobile.empty) return res.status(409).json({error:"This mobile number is already registered with IDWP."});
    const referralSnap = await db.collection("users").where("userID","==",p.referral).limit(1).get();
    if (referralSnap.empty) return res.status(400).json({error:"Referral ID is no longer valid. Please contact IDWP Support."});
    let userID = null;
    for (let i=0;i<15;i++) {
      const candidate = generateUserID();
      const exists = await db.collection("users").where("userID","==",candidate).limit(1).get();
      if (exists.empty) { userID = candidate; break; }
    }
    if (!userID) return res.status(500).json({error:"Could not generate a unique IDWP User ID. Please try again."});
    await userRef.set({
      uid:decoded.uid,userID,name:p.name,mobile:p.mobile,mobileNormalized:p.mobileNormalized,whatsapp:p.whatsapp,email:p.email,referral:p.referral,
      package:p.package,packagePrice:PACKAGES[p.package],packageActive:false,earnings:0,workEarnings:0,referralEarnings:0,pending:0,
      pendingReferralCommission:0,availableReferralCommission:0,referralCommissionAvailableAt:null,nextReferralPayoutAt:null,
      directReferralCount:0,level:0,referralCommissionRate:0.20,freePackageEligible:false,freePackageClaimed:false,
      emailVerified:true,registrationEmailVerified:true,createdAt:admin.firestore.FieldValue.serverTimestamp(),updatedAt:admin.firestore.FieldValue.serverTimestamp()
    });
    await pendingRef.delete();
    return res.status(200).json({success:true,userID,registration:{name:p.name,whatsapp:p.whatsapp,package:p.package}});
  } catch (e) {
    console.error("complete-registration error:", e.message);
    return res.status(500).json({error:"Could not finish registration. Please try again."});
  }
};
