// Single Vercel Serverless Function dispatcher for the IDWP API.
// Handlers are kept outside /api so Hobby deployments stay within the function limit.
const handlers = {
  "begin-registration": require("../handlers/begin-registration"),
  "claim-free-package": require("../handlers/claim-free-package"),
  "complete-registration": require("../handlers/complete-registration"),
  "confirm-profile-change-link": require("../handlers/confirm-profile-change-link"),
  "confirm-register-link": require("../handlers/confirm-register-link"),
  "create-order": require("../handlers/create-order"),
  "my-referrals": require("../handlers/my-referrals"),
  "payout-status": require("../handlers/payout-status"),
  "request-profile-change-link": require("../handlers/request-profile-change-link"),
  "request-register-link": require("../handlers/request-register-link"),
  "request-withdrawal": require("../handlers/request-withdrawal"),
  "resolve-login": require("../handlers/resolve-login"),
  "send-login-otp": require("../handlers/send-login-otp"),
  "send-register-otp": require("../handlers/send-register-otp"),
  "validate-mobile": require("../handlers/validate-mobile"),
  "validate-referral": require("../handlers/validate-referral"),
  "verify-login-otp": require("../handlers/verify-login-otp"),
  "verify-payment": require("../handlers/verify-payment"),
  "verify-register-otp": require("../handlers/verify-register-otp")
};

module.exports = async function handler(req, res) {
  const pathname = String(req.url || "").split("?")[0];
  const route = pathname.replace(/^\/api\//, "").replace(/\/$/, "").split("/")[0];

  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    return res.status(204).end();
  }

  const target = handlers[route];
  if (!target) {
    res.setHeader("Content-Type", "application/json");
    return res.status(404).send(JSON.stringify({ success: false, error: "Unknown API endpoint" }));
  }
  return target(req, res);
};
