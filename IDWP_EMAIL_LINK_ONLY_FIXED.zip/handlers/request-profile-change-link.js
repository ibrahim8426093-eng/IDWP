const crypto = require("crypto");
const { initFirebase, methodGuard } = require("../firebase-helper");
function mobile(v){return String(v||"").replace(/\D/g,"");}
function emailValid(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);}
module.exports = async function handler(req,res){
  if(methodGuard(req,res)) return;
  try{
    const admin=initFirebase(), db=admin.firestore();
    const authHeader=String(req.headers.authorization||"");
    if(!authHeader.startsWith("Bearer ")) return res.status(401).json({success:false,error:"Please log in again before requesting profile changes."});
    const decoded=await admin.auth().verifyIdToken(authHeader.slice(7));
    const uid=decoded.uid, body=req.body||{}, x=body.changes||{};
    const name=String(x.name||"").trim(), newMobile=mobile(x.mobile), whatsapp=mobile(x.whatsapp), newEmail=String(x.email||"").trim().toLowerCase();
    if(name.length<2||name.length>80) return res.status(400).json({success:false,error:"Enter a valid name (2-80 characters)."});
    if(!/^[6-9]\d{9}$/.test(newMobile)||!/^[6-9]\d{9}$/.test(whatsapp)) return res.status(400).json({success:false,error:"Enter valid 10-digit Indian mobile and WhatsApp numbers."});
    if(!emailValid(newEmail)) return res.status(400).json({success:false,error:"Enter a valid email address."});
    let userRef=db.collection("users").doc(uid), userSnap=await userRef.get();
    if(!userSnap.exists){const q=await db.collection("users").where("uid","==",uid).limit(1).get();if(!q.empty){userRef=q.docs[0].ref;userSnap=q.docs[0];}}
    if(!userSnap.exists) return res.status(404).json({success:false,error:"IDWP profile not found."});
    const current=userSnap.data()||{};
    const currentEmail=String(current.email||decoded.email||"").trim().toLowerCase();
    if(!currentEmail) return res.status(400).json({success:false,error:"Your current registered email is missing. Contact IDWP support."});
    if(name===String(current.name||"") && newMobile===mobile(current.mobile) && whatsapp===mobile(current.whatsapp||current.whatsappNumber) && newEmail===currentEmail)
      return res.status(400).json({success:false,error:"No profile detail has changed."});
    const mobileSnap=await db.collection("users").where("mobileNormalized","==",newMobile).limit(2).get();
    if(!mobileSnap.empty && mobileSnap.docs.some(d=>d.id!==userRef.id)) return res.status(409).json({success:false,error:"This mobile number is already registered with IDWP."});
    if(newEmail!==currentEmail){try{const existing=await admin.auth().getUserByEmail(newEmail);if(existing.uid!==uid)return res.status(409).json({success:false,error:"That email is already used by another IDWP account."});}catch(e){if(e.code!=="auth/user-not-found")throw e;}}
    const token=crypto.randomBytes(32).toString("hex"), hash=crypto.createHash("sha256").update(token).digest("hex");
    await db.collection("pendingProfileChanges").doc(hash).set({uid,userDocId:userRef.id,currentEmail,changes:{name,mobile:newMobile,mobileNormalized:newMobile,whatsapp,email:newEmail},expiresAt:Date.now()+30*60*1000,used:false,createdAt:admin.firestore.FieldValue.serverTimestamp()});
    const apiKey=process.env.RESEND_API_KEY, from=process.env.RESEND_FROM_EMAIL;
    if(!apiKey||!from){await db.collection("pendingProfileChanges").doc(hash).delete();return res.status(500).json({success:false,error:"Email service is not configured in Vercel."});}
    const link="https://ibrahim8426093-eng.github.io/IDWP/?confirmProfileChange="+encodeURIComponent(token);
    const safeName=name.replace(/[<>&\"]/g,"");
    const er=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:"Bearer "+apiKey,"Content-Type":"application/json"},body:JSON.stringify({from,to:[currentEmail],subject:"Confirm your IDWP profile changes",text:`Hello ${safeName},\n\nA request was made to change your IDWP profile. Review and confirm these changes using this one-time link within 30 minutes:\n${link}\n\nIf you did not request this, ignore this email. No changes will be applied unless the link is confirmed.\n\nIDWP Support`,html:`<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:24px;color:#172033"><h2>Confirm your IDWP profile changes</h2><p>Hello ${safeName},</p><p>A request was made to change your IDWP profile details (name, mobile, WhatsApp or email).</p><p><a href="${link}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:13px 20px;border-radius:9px;font-weight:bold">Review &amp; Confirm Changes</a></p><p>This one-time link expires in 30 minutes. No changes will be applied unless you confirm.</p><p>If you did not request this, ignore this email.</p><p>IDWP Support</p></div>`})});
    if(!er.ok){console.error("Resend profile-change email error",er.status,await er.text());await db.collection("pendingProfileChanges").doc(hash).delete();return res.status(502).json({success:false,error:"Could not send confirmation email. Please try again."});}
    return res.status(200).json({success:true,message:"Profile confirmation link sent."});
  }catch(e){console.error("request-profile-change-link error",e.message);return res.status(500).json({success:false,error:"Could not request profile change confirmation. Please try again."});}
};
