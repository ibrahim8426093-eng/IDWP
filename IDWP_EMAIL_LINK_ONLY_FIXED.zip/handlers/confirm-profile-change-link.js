const crypto = require("crypto");
const { initFirebase, methodGuard } = require("../firebase-helper");
function mobile(v){return String(v||"").replace(/\D/g,"");}
module.exports = async function handler(req,res){
  if(methodGuard(req,res)) return;
  try{
    const token=String((req.body||{}).token||"");
    if(!/^[a-f0-9]{64}$/.test(token)) return res.status(400).json({success:false,error:"Invalid confirmation link."});
    const admin=initFirebase(), db=admin.firestore();
    const hash=crypto.createHash("sha256").update(token).digest("hex"), ref=db.collection("pendingProfileChanges").doc(hash), snap=await ref.get();
    if(!snap.exists) return res.status(400).json({success:false,error:"This confirmation link is invalid or has already been used."});
    const p=snap.data()||{};
    if(p.used||!p.expiresAt||Date.now()>Number(p.expiresAt)){await ref.delete();return res.status(410).json({success:false,error:"This confirmation link has expired. Log in and request a new one."});}
    const userRef=db.collection("users").doc(String(p.userDocId||p.uid)), userSnap=await userRef.get();
    if(!userSnap.exists) return res.status(404).json({success:false,error:"IDWP profile not found."});
    const current=userSnap.data()||{}, x=p.changes||{};
    if(String(current.email||"").trim().toLowerCase()!==String(p.currentEmail||"").trim().toLowerCase()) return res.status(409).json({success:false,error:"The account email has changed since this request. Please request a new confirmation link."});
    const m=String(x.mobile||"").replace(/\D/g,"");
    if(!/^[6-9]\d{9}$/.test(m)||!/^[6-9]\d{9}$/.test(mobile(x.whatsapp))||String(x.name||"").trim().length<2) return res.status(400).json({success:false,error:"The requested profile details are invalid."});
    const mobileSnap=await db.collection("users").where("mobileNormalized","==",m).limit(2).get();
    if(!mobileSnap.empty&&mobileSnap.docs.some(d=>d.id!==userRef.id)) return res.status(409).json({success:false,error:"This mobile number is now used by another IDWP account. No changes were applied."});
    const newEmail=String(x.email||"").trim().toLowerCase();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) return res.status(400).json({success:false,error:"The requested email address is invalid."});
    if(newEmail!==String(current.email||p.currentEmail||"").trim().toLowerCase()){
      try{const existing=await admin.auth().getUserByEmail(newEmail);if(existing.uid!==p.uid)return res.status(409).json({success:false,error:"That email is already used by another account. No changes were applied."});}catch(e){if(e.code!=="auth/user-not-found")throw e;}
      await admin.auth().updateUser(p.uid,{email:newEmail,emailVerified:true});
    }
    await userRef.update({name:String(x.name).trim(),mobile:m,mobileNormalized:m,whatsapp:mobile(x.whatsapp),email:newEmail,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
    await ref.delete();
    return res.status(200).json({success:true,message:"Profile changes confirmed and applied."});
  }catch(e){console.error("confirm-profile-change-link error",e.message);return res.status(500).json({success:false,error:"Could not apply profile changes. Please contact IDWP support if the issue continues."});}
};
