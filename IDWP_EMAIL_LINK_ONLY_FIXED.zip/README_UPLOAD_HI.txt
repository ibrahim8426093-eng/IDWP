IDWP EMAIL-LINK-ONLY PACKAGE (Vercel Hobby)

Registration flow:
- Registration sends a confirmation link to the user's email.
- The new IDWP user ID is created only after the email link is confirmed.
- Registration OTP endpoints are intentionally removed. Login OTP remains available.

IMPORTANT DEPLOY INSTRUCTIONS:
1. Extract this ZIP.
2. In the GitHub repository root, keep index.html, package.json, vercel.json, firebase-helper.js and ibrahim-founder.jpg at root.
3. Replace the whole existing api folder with the single api/[...route].js file from this package. Delete the old individual files inside api (including old .js endpoints and the extensionless validate-referral file) before committing. Do NOT delete the handlers folder.
4. Upload the handlers folder at repository root. It contains backend handlers outside /api, so Vercel should build only the catch-all API function.
5. Commit changes; wait for Vercel deployment.
6. Keep existing Vercel environment variables. Email registration needs RESEND_API_KEY, RESEND_FROM_EMAIL, REGISTRATION_ENCRYPTION_KEY and Firebase service-account settings.

Do not upload the ZIP file itself as the only repository file. Extract it and upload its contents preserving folders.
This package has not been deployed or live-tested from your account; after deployment, test registration link, confirmation, login, and other features.
